# Sakura Birthday Website — Deploy Guide 🌸

Yeh ek single `index.html` file hai — photo bhi isi ke andar embed hai, to deploy karna bahut simple hai. Koi build step nahi chahiye.

## Option 1: Vercel CLI (sabse fast, ~2 min)
1. Is folder ko apne laptop/PC mein unzip karo.
2. Terminal khol ke usi folder mein jao (jahan `index.html` hai).
3. Yeh commands chalao:
   ```
   npm i -g vercel
   vercel
   ```
4. Pehli baar login/signup mangega (free hai, GitHub/Google se ho jata hai).
5. Baki sawalon mein bas Enter dabate jao (defaults theek hain).
6. Deploy hote hi terminal mein ek link milega jaisa: `https://sakura-birthday-xxxx.vercel.app`
   — yahi link Sakura ko bhejna hai.

   (Agar future mein update karna ho, isi folder mein dubara `vercel --prod` chala dena.)

## Option 2: Vercel Dashboard (no terminal)
1. https://vercel.com pe free sign up karo.
2. "Add New..." → "Project".
3. Folder ko GitHub pe push karke wahan se import kar sakte ho, ya direct "Deploy" screen pe folder drag-drop ka option dhoondo.
4. Deploy hote hi live link mil jayega.

## Option 3: Netlify Drop (signup tak nahi chahiye, sabse easy)
1. https://app.netlify.com/drop khol.
2. Is poore folder ko wahan drag-drop kar do.
3. 10 second mein live link mil jayega — turant share kar sakte ho.

## Zaroori baat ⚠️
- **Candle "phoonk maar ke bujhana" (mic) wala feature sirf HTTPS link par kaam karega** — Vercel aur Netlify dono automatically HTTPS dete hain, to deploy karne ke baad bilkul chalega.
- Agar seedha `index.html` file double-click karke localy khologe, mic permission browser nahi dega (security restriction) — lekin candles tap karke bhi bujha sakte ho, woh hamesha kaam karega.
- Naye photos add karwane ho ya text mein kuch change karwana ho, file mujhe bhej dena ya yahin bata dena — main update kar dunga.
